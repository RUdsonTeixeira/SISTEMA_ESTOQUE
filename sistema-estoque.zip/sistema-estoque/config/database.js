module.exports= {
    dialect:"postgres",
    host:"localhost",
    username:"postgres", 
    password:"ifms",
    database:"sistema_estoque",
    define:{
        timestamps:false,
        underscored:true
    }
}