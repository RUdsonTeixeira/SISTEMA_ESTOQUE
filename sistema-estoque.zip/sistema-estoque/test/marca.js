const Marca = require('../models/Marca')

Marca.create({nome:"Nestle"})

//outra forma de inserir 
//let marca = new Marca()
//marca.nome = "Nestle"
//marca.save()